Use with:

No Intro
Sonic Battle (USA) (En,Ja,Fr,De,Es,It).gba
100579EF01225C620560F88E65CA423A
9EC9D86F