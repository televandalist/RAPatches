Use with:

(No-Intro)
File:               Fire Emblem - The Sacred Stones (USA, Australia).gba
Size (Bytes):       16777216
CRC32:              a47246ae
MD5:                005531fef9efbb642095fb8f64645236
SHA1:               c25b145e37456171ada4b0d440bf88a19f4d509f