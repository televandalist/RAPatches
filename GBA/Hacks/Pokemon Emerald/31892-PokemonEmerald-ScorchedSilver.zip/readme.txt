Use with:

(No-Intro)
File:               Pokemon - Emerald Version (USA, Europe).gba
Size (Bytes):       16777216
CRC32:              1f1c08fb
MD5:                605b89b67018abcea91e693a4dd25be3
SHA1:               f3ae088181bf583e55daf962a92bb46f4f1d07b7