Use with:

(No Intro)
File:               Pokemon - Emerald Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              1F1C08FB
MD5:                605B89B67018ABCEA91E693A4DD25BE3
SHA1:               F3AE088181BF583E55DAF962A92BB46F4F1D07B7
SHA256:             A9DEC84DFE7F62AB2220BAFAEF7479DA0929D066ECE16A6885F6226DB19085AF