Hello, this is a "successor" to R-ACK with the usual bullshit in it. If you enjoy the yumplikes, you'll love this...probably.

A "yumplike" is a romhack where people throw ideas at a wall and see what sticks. Aesthetics being bad/unpolished is part of the fun, confusion is part of the game, and all jokes/visual gags are made to be laughed at. Speling miztakes are also (probably) intentional, and swear words can be censored or uncensored without any consistency.

It is the same deal as R-ACK; the rules were thrown out the window and turned into a "make whatever your heart desires" kind of experience. It's not a ruleless collab, we had the obvious stuff (making it moderately* playable), but otherwise you're in for a WILD ride. Items can be found in the various storehouses to assist in gameplay...maybe.

In terms of like, lore I guess? The Plumber continues his conquest in R-ACK when he finds a level that seems out of place. Where does it lead? Find out. All the writing is shared between creators, and are non-canon in any existing series.

There are 100 exits; good luck getting all of them if you wish to suffer the 100% grind. This is harder than R-ACK by miles in the lategame. It gets hard right when you reach World 5. Don't expect to beat the postgame levels unscathed; even the most skilled players consider the stages brutal to finish. Yet, none of them will require any "kaizo" tech.

	h

Hack lead by Daizo Dee Von and Squirrelyman157. Most of the level creators are forever anonymous.
(There are some levels that can cause potential flashing due to the gimmicks at hand. But look, it's not deliberate this time.)
(Also, "phuque" bombs are present. Oops.)

!!!!!!!!!!!!!!!!!!!!
~~ SPOILERS BELOW ~~
!!!!!!!!!!!!!!!!!!!!
  - 1.0.4B - "The Most Minor of Updates"
- Fixed all Star Pads
- Added powerup filter in "Règle du ballon à l'avant-champ"
- Added the FNAF Grandfather Clock jingle for when you beat Springtrap

  - 1.0.4 - "Perging of Artificial Infractions and Softlocks"
- Redone EVIGI's second frame see in the "Two Gods in a Pocket" cutscene (due to it being a Neuralblender render...aka, AI)
	- (The new one is using a model submitted by TeridaxXD001 from the Models Resource...and I had to re-learn how to use blender lol.)
- Replaced portrait in CAPITALISM HIGHWAY (Potentially AI art, we're not sure but we didn't want to take any risks.)
- Tweaked "House of Locks" (made secret exit path indicated)
- Tweaked "Règle du ballon à l'avant-champ" (added "kills" counter, and one specter no longer easily despawns)
- Tweaked "GUYS i JUSdt invented slOPEd deathbloks" (added more BSP blocks so it's more obvious it's there)
- Fixed softlock during the Final Boss relating to perfectly aiming it straight forward. (Reported by luckybacon)
	- this was caused by the boss not being able to find any ground because he'll never reach it since his y speed is 0.
- Fixed a pause softlock in TERRA TUBES' game over screen. (Reported by luckybacon)
- Fixed some overworld tiles being water tiles thanks to a newly discovered Lunar Magic feature.
- Fixed fireworks festival 50XX's yellow switch palace blocks (just by changing the map16 tile to object tiles)
- Added a secret ending to "fix" an oversight.
- Added new level tiles on the overworld
- Added new pipe tiles on the overworld (to further clearify what pipe goes where)
- Added a 'door' tile on the overworld that only takes you one way
- Added a lowercase font for cutscenes, alongside fixing a lot of grammar errors.
- Added a new song for TOWER OF THE EXITS (one that was [FUN FACT] temporarily used during development until the new song was written)
- Added StayAtHomeStegosaurus as a tester.
-   and one more secret...
- Removed Herobrine.

Note: This is a silly game made by silly people, who ultimately want to do what's best while still having a laugh.
Our use of AI prior to this update was simply made for jokes. It is removed courtesy of the new rule change, and we want to hold up to standard as a "Hall of Fame" ROM Hack.

  - 1.0.3B
- Fixed softlocked midpoint in House of Locks
- Removed Herobrine.

  - 1.0.3 - "Ad-juz-tments Fit for a KING ~ The Betterified Update"
- Added a BOOM BOX in "The Tower of the Exits ~ A Plumber for all Destiny" (BarbarousKing & chat)
	- By proxy, "R-ACK - real final" has been added as an alternate track.
	- By proxy, "A Second Mario Thing - Trials of the Parrot (Early Version)" has been added as an alternate track. (raocow)
	- By proxy, Wyatt is added to the credits.
	- All other castle themes are selectable using the BOOM BOX.
	- The default SMW Castle theme is selectable.
	- You can also turn off the music. (Hwailaluta)
- Added a new SECRET SUPER BOSS. (Team JANK)
- Added a new track FOR THE SECRET BOSS. (Team JANK)
- Added a BRAND NEW SECRET ENDING(?) (Team JANK)
- Added a STAR HUB to every storehouse so you can traverse between them. (@everyone)
- Added a STAR leading to The Brick if you beat "Tower of Powser."
- Added Kipernal to the music and porters portion of the credits.
- Added a quick warp to the other side of "The Tower of the Exits" (every. single. person.)
- Added some clearity in "No good very bad coins" (juzcook)
- Added level length meter in "Lavitation Me" (juzcook)
- Added Tim Carleton and Derrick Deel for the source sample of THE BRICK's overworld theme (Opus No. 1).
- Added a lot of NPCs in the credits.
- Added an indicator on when or when not you can talk to an NPC.
- Added a second message box in "Tanooki Pass"
- Added warnings to every THE BRICK level; labeling them appropriately. (juzcook)
- Added statues of the SECONDARY EXITS in both the intro and the Tower of the Exits.
- Added a snow effect in the World 7 map.
- Added THE FOUR FALLEN SOULS OF JANK.
- Added many MARIO references for literally no reason.
- Added MARIO and Betterified VI: Bestified to the credits as inspirations.
- (Re)Added info box in "I Forced A Tester To Make A Level" (Anorakun)
- Removed the last hammer brother in "Lavitation Me" (juzcook)
- Removed the use of L/R in "Tetris Explosion." (BarbarousKing)
- Removed the use of L/R in "Greece." (Anorakun)
- Removed the "support local bakeries" message box from This Level Is Sponsored.
- Changed "fireworks festival 50XX" from "medium / sick" difficulty to "medium puzzle" difficulty. (juzcook)
- Fixed spelling in the 100% cutscene. (Hwailaluta, juzcook)
- Fixed discoloured invisible note block indicators in "CAPITALISM HIGHWAY" (Amethyst, juzcook)
- Fixed game over theme for TERRA TUBES.
- Fixed hammer brothers in "Lavitation Me" (juzcook)
- Fixed an handful of issues with the castle portion of "A Normal SMB3 Stage" (Anorakun)
- Tweaked ingame timers in various levels (Anorakun)
- Tweaked 3rd exit in "The coin flip" (juzcook)
- Tweaked the final boss a touch.
- Anti-cheesed "No good very bad coins" (juzcook)
- Anti-cheesed "House of Locks" (juzcook)
- Anti-cheesed "GUYS i JUSdt invented slOPEd deathbloks" (TheKazooBloccGosh)
 -      wowie talk about a readme in my view (Valentine, et al.)
- "This level is sponsored." completely recoded by mellonpizza. (Daizo Dee Von)
- Switch Palace exploit fixed by mellonpizza. (Amethyst)
- The long-awaited special thanks and early playing credit to juzcook. Even gave him the 100% tag for being a trooper (not shown
in the ~omh~ vods and the inevitable ~omh~ YouTube series [wink wink]).
- The rom has been transferred. Actually was transferred seven times. There's nothing special in relation to this; I'm just
putting this here to feel better.
- Re-introduced BLOODMAN into the canon (aka the Giygas "Just Right" meme thing from R-ACK)
- ...as well as many other tiny adjustments that I can't quite remember ontop of my head.
- Somehow Herobrine returned. (God damn it)

  - 1.03-J- and 1.03-JUZ- - "The Storyteller's Update"
- Versions for Juzcook Only
- Somehow Herobrine returned.

  - 1.02 - "The 'I Can't Believe I Missed These' Update"
- Fixed an exploit that can be triggered in Level 2 to bypass boss levels & luigi globetrotter (NES Boy)
- Fixed secret "NO LIVES" item; now the retry prompt cannot decrease lives. (Amethyst)
- Typo fixed in the pit of "Wait, there's not supposed to be a level here." (Anorakun)
- Removed message box in "I FORCED A TESTER TO MAKE A LEVEL" (TheKazooBloccGosh)
- Expanded the detour in Grassy Mountain, linking back to the proper exit (TheKazooBloccGosh)
- Added a hint in "I always come back" if you die to Springtrap (TheKazooBloccGosh)
- Changed Bonus Game (level0/100)
- Re-added door to hub in Big Bill's Hell (TheKazooBloccGosh)
- Various tweaks to difficulty ratings (TheKazooBloccGosh)
- Added difficulty ratings in luigi globetrotter.
- Credited EvilGuy0613 for postcredits (request)
- Storehouse icon now appears in Om Homh. (TheKazooBloccGosh)
- The Kingpin/Scissorman credited in Snowbarrage House.
- Added mushroom in Cemencio
- Fixed arrow signs on overworld (TheKazooBloccGosh)
- Various Easter Eggs:
	- Added a 3/10 sign.
	- Added GOLDEN FREDDY.
	- Added a Turtle Thumbup emote.
	- Added access to the unused boss fight (test boss).
	- Added Bones Popcorn
	- Added Victim #1 poster
- Removed Herobrine

  - 1.01 - "The Feedback Update"
- Fixed reset door in "mario has a tragic accident" (Katerpie)
- Reverted arrows on the overworld to point one direction (TheKazooBloccGosh)
- Tweaked difficulty ratings through suggestion (TheKazooBloccGosh)
- Green dot appears after beating "Règle du ballon à l'avant-champ" (TheKazooBloccGosh)
- No longer possible to bring powerups in "Wait, there's not supposed to be a level here" (TheKazooBloccGosh)
- Darude Sandstorm is now the star theme.
- Removed Herobrine

  - 1.00 - "Official Release"
- Added credits
- Added various missing checkpoints
- Added lives and exit count to the overworld
- Added Donkey Kong Country 2 Arrows to the overworld
- Added STAR DIFFICULTIES per level (press START on a level tile to see; visit "Om Homh" for info on all the types).
- Added MANY NPCs
- Added BRAND NEW BOSS in "h3."
- Added defeat dialogue for all secondary exits (HOT LORE FOR ONLY [Juzcook, for president?] !!)
- Added new custom music
- Added new cutscene
- Added 100 exit reward
- Added health bar to William Afton + buffed your attacks against him
- Added R-ACK's border in cat world.
- Added a super secret easter egg in luigi globetrotter
- Added new Wendy O Koopa graphic
- Added proper warning before you enter the postgame world.
- "CARD IDs" can now change author names in "Tower of the Exits."
- Every message box data in the rom is used
- Tweaked:
	- "Mario has a tragic accident"
	- "fireworks festival 50XX - looking for the past glory"
	- "A Normal SMB3 Stage" (Boss)
	- "Pre-rendered Deadly Glucose"
	- "luigi globetrotter (Greece)"
	- "There is a dragon in my tomato soup"
	- "Règle du ballon à l'avant-champ"
	- "I forced a Team JANK member to use handpicked resources"
	- "Chat makes a level"
	- "The Tower of the Exits ~ A Plumber for all Destiny" (hub, saw-not mill-thrill, big bill hell's, final boss, credits)
	- "A Möbius strip made with paper and adhesive tape"
	- The starman theme
- Changed pseudonym "RockMan287" to "The Other Hair"
- Fixed various unintended spelling mistakes (assume the leftovers are intended)
- Fixed wallmaster room.
- Fixed various wrong information in the level information boxes.
- You can now re-visit cat world if you beat the game but don't re-enter the pipe you come from (exiting from
"Wait there isn't a level here").
- Removed Herobrine

  - 0.91 -
- Moved the base event of Capitalism Highway (DON'T BEAT IT ON 0.9.0 OR YOU WILL LOCK YOURSELF FROM THE REST OF THE GAME)
- Added retry & subroom checkpoint to Good and Evil Place
- Added a brand new item in Impurity City; the "ID Cards" (singular)

  - 0.90 -
- Early Beta Release
- Note about this version, there's no credits as we're trying to organize a list. When it's submitted on SMW Central, it will be present. We promise.
- But shoutouts to PaperKitty for one of the boss songs which one of us ported, as well as Argonfunk/Xanol for some of the ports from youtube specifically.

  - 0.00 -
- Super Mario World

  - -∞.∞∞ -
- The big bang occured, creating the universe.
- (Some debate if it was actually an 11th dimensional being who created it.)









*moderate in the sense that it's been beaten RTA. Level design standards may vary. Player's discretion is advised.